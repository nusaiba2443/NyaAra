function updateDateTime(){

    let now = new Date(); 
    let date = now.toLocaleDateString();
    let time = now.toLocaleTimeString();

    document.getElementById("date").innerText = date
    document.getElementById("time").innerText= time 
} 
setInterval(updateDateTime,1000);
 const courses = {
"video-editing": {
title: "Video Editing",
category: "IT Course",
image: "Asset/video editing.jpg",
overview: "Learn professional video editing techniques and create engaging visual content.",
duration: "3 Months",
fee: "৳5,000",
instructor: "Expert Instructor"
},
"graphic-design": {
title: "Graphic Design",
category: "IT Course",
image: "Asset/GraphicDesignj.jpg",
overview: "Build creative design skills using modern tools and techniques.",
duration: "3 Months",
fee: "৳5,000",
instructor: "Expert Instructor"
},
"digital-marketing": {
title: "Digital Marketing",
category: "IT Course",
image: "Asset/digital marketing.jpg",
overview: "Learn digital promotion, social media and marketing strategies.",
duration: "3 Months",
fee: "৳5,000",
instructor: "Expert Instructor"
},
"web-development": {
title: "Web Development",
category: "IT Course",
image: "Asset/web development.jpg",
overview: "Learn how to create modern and responsive websites.",
duration: "4 Months",
fee: "৳6,000",
instructor: "Expert Instructor"
},
"programming": {
title: "Programming",
category: "IT Course",
image: "Asset/programming.jpg",
overview: "Develop programming knowledge and problem-solving skills.",
duration: "4 Months",
fee: "৳6,000",
instructor: "Expert Instructor"
},
"computer-applications": {
title: "Computer Applications",
category: "IT Course",
image: "Asset/computer.jpg",
overview: "Learn essential computer applications and workplace skills.",
duration: "3 Months",
fee: "৳4,000",
instructor: "Expert Instructor"
},
"english-language": {
title: "English Language",
category: "Language Course",
image: "Asset/english.jpg",
overview: "Improve your English communication, vocabulary and language skills.",
duration: "3 Months",
fee: "৳5,000",
instructor: "Language Instructor"
},
"japanese-language": {
title: "Japanese Language",
category: "Language Course",
image: "Asset/japanese.jpg",
overview: "Learn Japanese language and develop practical communication skills.",
duration: "6 Months",
fee: "৳8,000",
instructor: "Japanese Instructor"
},
"chinese-language": {
title: "Chinese Language",
category: "Language Course",
image: "Asset/chinese.jpg",
overview: "Build basic Chinese language and communication skills.",
duration: "6 Months",
fee: "৳8,000",
instructor: "Chinese Instructor"
},
"korean-language": {
title: "Korean Language",
category: "Language Course",
image: "Asset/korean.jpg",
overview: "Learn Korean language through structured lessons and practice.",
duration: "6 Months",
fee: "৳8,000",
instructor: "Korean Instructor"
},
"german-language": {
title: "German Language",
category: "Language Course",
image: "Asset/german.jpg",
overview: "Develop practical German language and communication skills.",
duration: "6 Months",
fee: "৳8,000",
instructor: "German Instructor"
},
"french-language": {
title: "French Language",
category: "Language Course",
image: "Asset/french.jpg",
overview: "Learn French language and improve everyday communication skills.",
duration: "6 Months",
fee: "৳8,000",
instructor: "French Instructor"
},
"ielts-academic": {
title: "IELTS Academic",
category: "IELTS",
image: "Asset/ielts.jpg",
overview: "Prepare for the IELTS Academic test with structured lessons and practice.",
duration: "3 Months",
fee: "৳6,000",
instructor: "IELTS Instructor"
},
"ielts-general": {
title: "IELTS General Training",
category: "IELTS",
image: "Asset/ielts2.jpg",
overview: "Develop the skills needed for the IELTS General Training test.",
duration: "3 Months",
fee: "৳6,000",
instructor: "IELTS Instructor"
},
"ielts-speaking": {
title: "IELTS Speaking",
category: "IELTS",
image: "Asset/ielts3.jpg",
overview: "Improve speaking fluency, vocabulary and confidence for IELTS.",
duration: "2 Months",
fee: "৳4,000",
instructor: "IELTS Instructor"
},
"ielts-writing": {
title: "IELTS Writing",
category: "IELTS",
image: "Asset/ielts4.jpg",
overview: "Practice IELTS writing tasks and develop effective writing techniques.",
duration: "2 Months",
fee: "৳4,000",
instructor: "IELTS Instructor"
},
"ielts-reading": {
title: "IELTS Reading",
category: "IELTS",
image: "Asset/ielts5.jpg",
overview: "Develop reading strategies and practice different IELTS question types.",
duration: "2 Months",
fee: "৳4,000",
instructor: "IELTS Instructor"
},
"ielts-listening": {
title: "IELTS Listening",
category: "IELTS",
image: "Asset/ielts6.jpg",
overview: "Improve listening skills through IELTS-focused practice and exercises.",
duration: "2 Months",
fee: "৳4,000",
instructor: "IELTS Instructor"
}
};
const params = new URLSearchParams(window.location.search);
const courseKey = params.get("course");

if (courseKey && courses[courseKey]) {
const course = courses[courseKey];

document.getElementById("courseTitle").textContent = course.title;
document.getElementById("courseCategory").textContent = course.category;
document.getElementById("courseImage").src = course.image;
document.getElementById("courseImage").alt = course.title;
document.getElementById("courseOverview").textContent = course.overview;
document.getElementById("courseDuration").textContent = course.duration;
document.getElementById("courseFee").textContent = course.fee;
document.getElementById("courseInstructor").textContent = course.instructor;
document.getElementById("infoDuration").textContent = course.duration;
document.getElementById("infoFee").textContent = course.fee;
document.getElementById("infoInstructor").textContent = course.instructor;

document.title = course.title + " | Global IT Institute";
}
