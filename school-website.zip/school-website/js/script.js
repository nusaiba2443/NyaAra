JavaScript is intentionally not used in this version because the user requested an HTML + CSS only website.
