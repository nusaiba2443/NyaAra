 function DateTime(){
    let now= new Date(); 
 let date = now.toLocaleDateString();
 let time = now.toLocaleTimeString();
  document.getElementById('date').innerText= date
  document.getElementById('time').innerText= time

 }
 setInterval(DateTime, 1000)